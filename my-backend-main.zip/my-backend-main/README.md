```javascript
-> Endpoint Structure
# /api/(folder)/(file)
# /api/(file)
```
